﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;
using System.Net;
using Windows.ApplicationModel.Appointments;

namespace FurkAPI
{
    public class Module
    {

        private WebClient client = new WebClient();

        public int ExecuteScript(string Script)
        {
            if (Module.namedPipeExist("ocybedam"))
            {
                using (NamedPipeClientStream pipeClientStream = new NamedPipeClientStream(".", "ocybedam", PipeDirection.Out))
                {
                    pipeClientStream.Connect();
                    using (StreamWriter streamWriter = new StreamWriter((Stream)pipeClientStream, Encoding.Default, 999999))
                    {
                        streamWriter.Write(Script);
                        streamWriter.Dispose();
                    }
                    pipeClientStream.Dispose();
                    return 0;
                }
            }
            else
            {
                return 1;
            }
        }

        public async Task<int> Init()
        {
            string filename;
            if (Module.namedPipeExist("ocybedam"))
            {
                filename = (string)null;
                return 1;
            }
            else
            {
                string uriString = await this.client.DownloadStringTaskAsync("https://raw.githubusercontent.com/tommarekCZE/FurkAPI/main/currentapp.txt");
                filename = ((IEnumerable<string>)uriString.Split('/')).Last<string>();
                await this.client.DownloadFileTaskAsync(new Uri(uriString), filename);
                Process.Start(filename);
                filename = (string)null;
                return 0;
            }
        }

        public bool isInjected() => Module.namedPipeExist("ocybedam");

        private static bool namedPipeExist(string pipeName)
        {
            try
            {
                if (!Module.WaitNamedPipe(Path.GetFullPath(string.Format("\\\\.\\pipe\\{0}", (object)pipeName)), 0))
                {
                    switch (Marshal.GetLastWin32Error())
                    {
                        case 0:
                            return false;
                        case 2:
                            return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool WaitNamedPipe(string name, int timeout);
    }


}
